import numpy as np
import matplotlib.pyplot as plt
import os
os.chdir('/home/daf/Current/Courses/CS307/LinearClassifier')
npdata=np.genfromtxt('clabalone.txt', delimiter=',')
ukdata=npdata[npdata[:, 0]==0, 1:npdata.shape[1]]
cleandata=npdata[~(npdata[:, 0]==0), 1:npdata.shape[1]]
cleandata=cleandata/np.std(cleandata, axis=0, keepdims=1)
cleandata=cleandata-np.mean(cleandata, axis=0)
##
cleanlabels=npdata[~(npdata[:, 0]==0), 0]
# what is variance over splits
nsplits=5
splacc=np.zeros(nsplits)
for wri in range(0, nsplits):
    splitflag=(np.random.rand(cleandata.shape[0])<0.9)
    # so 10% of data for final evaluation
    traindata=cleandata[splitflag, :]
    testdata=cleandata[~splitflag, :]
    trainlabels=cleanlabels[splitflag]
    testlabels=cleanlabels[~splitflag]
    avec=np.random.rand(cleandata.shape[1])
    bval=1
    nseasons=1000
    la=0.1
    step=1e-2
    nps=10
    nexamples=np.zeros(nseasons)
    traccuracy=np.zeros(nseasons)
    valaccuracy=np.zeros(nseasons)
    for i in range(0, nseasons):
        # train a bunch
        for j in range(0, nps):
            ptr=np.random.randint(0, traindata.shape[0])
            weg=traindata[ptr, :]
            val=np.sum(weg*avec)+bval
            if val*trainlabels[ptr]>1:
                davec=la*avec
                dbval=0
            else:
                davec=-weg*trainlabels[ptr]+la*avec
                dbval=-trainlabels[ptr]
            avec=avec-step*davec
            bval=bval-step*dbval
        # check
        wvs=np.sum(traindata*avec, axis=1)+bval
        gamy=wvs*trainlabels
        hlv=1-gamy
        nexamples[i]=(i+1)*nps
        traccuracy[i]=np.mean(gamy>0)
        tevals=np.sum(testdata*avec, axis=1)+bval
        gamy=tevals*testlabels
        valaccuracy[i]=np.mean(gamy>0)
    splacc[wri]=np.mean(gamy>0)
    
          
