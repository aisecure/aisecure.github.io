import numpy as np
import os
os.chdir('/home/daf/Current/Courses/CS307/LinearClassifier')
npdata=np.genfromtxt('clabalone.txt', delimiter=',')
ukdata=npdata[npdata[:, 0]==0, 1:npdata.shape[1]]
cleandata=npdata[~(npdata[:, 0]==0), 1:npdata.shape[1]]
cleandata=cleandata/np.std(cleandata, axis=0, keepdims=1)
cleandata=cleandata-np.mean(cleandata, axis=0)
##
cleanlabels=npdata[~(npdata[:, 0]==0), 0]
splitflag=(np.random.rand(cleandata.shape[0])<0.9)
# so 10% of data for final evaluation
traindata=cleandata[splitflag, :]
testdata=cleandata[splitflag, :]
trainlabels=cleanlabels[splitflag]
testlabels=cleanlabels[splitflag]
avec=np.random.rand(cleandata.shape[1])
bval=1
nseasons=100
la=0
step=1e-5
for i in range(0, nseasons):
    # train a bunch
    for j in range(0, 10000):
        ptr=np.random.randint(0, traindata.shape[0])
        weg=traindata[ptr, :]
        val=np.sum(weg*avec)+bval
        if val*trainlabels[ptr]>1:
            davec=la*avec
            dbval=0
        else:
            davec=-weg*trainlabels[ptr]+la*avec
            dbval=-trainlabels[ptr]
        avec=avec-step*davec
        bval=bval-step*dbval
    # check
    valptrs=np.random.rand(traindata.shape[0])<0.9
    wvs=np.sum(traindata[valptrs, :]*avec, axis=1)+bval
    gamy=wvs*trainlabels[valptrs]
    hlv=1-gamy
    print(np.mean((hlv>0)*hlv)+(la/2)*np.sum(avec*avec), (np.mean(gamy>0)))
          
