import numpy as np
import matplotlib.pyplot as plt
import os
os.chdir('/home/daf/Current/Courses/CS307/LinearClassifier')
npdata=np.genfromtxt('cleanraisins.csv', delimiter=',')
cleandata=npdata[~(npdata[:, 0]==0), 0:npdata.shape[1]-1]
cleandata=cleandata/np.std(cleandata, axis=0, keepdims=1)
cleandata=cleandata-np.mean(cleandata, axis=0)
##

def logreg(step, nseasons, nps, traindata, trainlabels, la, frac):
    splitflag=np.random.rand(traindata.shape[0])<frac
    wtr=traindata[splitflag, :]
    wte=traindata[~splitflag, :]
    ltr=trainlabels[splitflag]
    lte=trainlabels[~splitflag]
    avec=np.random.rand(cleandata.shape[1])
    bval=1
    nexamples=np.zeros(nseasons)
    traccuracy=np.zeros(nseasons)
    valaccuracy=np.zeros(nseasons)
    amag=np.zeros(nseasons)
    for i in range(0, nseasons):
    # train a bunch
        for j in range(0, nps):
            ptr=np.random.randint(0, wtr.shape[0])
            weg=wtr[ptr, :]
            val=np.sum(weg*avec)+bval
            gam=val*trainlabels[ptr]
            egm=np.exp(-gam)
            wgt=-egm/(1+egm)
            davec=wgt*trainlabels[ptr]*weg+la*avec
            dbval=wgt*trainlabels[ptr]
            avec=avec-step*davec
            bval=bval-step*dbval
    # check
        wvs=np.sum(wtr*avec, axis=1)+bval
        gamy=wvs*ltr
        hlv=1-gamy
        nexamples[i]=(i+1)*nps
        traccuracy[i]=np.mean(gamy>0)
        tevals=np.sum(wte*avec, axis=1)+bval
        gamy=tevals*lte
        valaccuracy[i]=np.mean(gamy>0)
        amag[i]=np.sum(avec**2)
    return nexamples, traccuracy, valaccuracy, amag  


cleanlabels=npdata[~(npdata[:, 0]==0), npdata.shape[1]-1]
splitflag=(np.random.rand(cleandata.shape[0])<0.9)
# so 10% of data for final evaluation
traindata=cleandata[splitflag, :]
testdata=cleandata[~splitflag, :]
trainlabels=cleanlabels[splitflag]
testlabels=cleanlabels[~splitflag]
avec=np.random.rand(cleandata.shape[1])
bval=1
lavec=[0.01, 0.1, 1]
step=1e-2
nps=100
nseasons=100
plt.style.use('seaborn')
fig=plt.figure()
ax=fig.add_subplot(111)
ax2=ax.twinx()
for i in range(0, 3):
    neg, tra, vla, amag=logreg(step, nseasons, nps, traindata, trainlabels, lavec[i], 0.9)
    ax.plot(neg, tra, label = 'Training accuracy')
    ax.plot(neg, vla, label = 'Validation accuracy')
    ax2.plot(neg, amag, label = 'magnitude')    

ax.set_ylabel(r'Accuracy', fontsize = 14)
ax.set_xlabel('Number of examples', fontsize = 14)
ax2.set_ylabel(r'Magnitude', fontsize=14)
plt.title('Accuracy for logistic regression on Raisins 3 la, step='+str(step), fontsize = 18, y = 1.03)
ax.legend()
ax.set_ylim(0,1)
ax2.set_ylim(0, 2)
plt.show()

