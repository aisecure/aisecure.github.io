import math
import csv
import numpy as np

npdata=np.genfromtxt('breast-cancer-wisconsin-data.csv', delimiter=',')
#
# we'll have to clean this up - there are ?'s in the data
goodflag=np.sum(np.isnan(npdata), axis=1)

print(npdata[0, :])
cleandata=npdata[goodflag==0, :]
alldata=cleandata[:, 1:10]
alllabels=cleandata[:, 10]

# a cross-validated estimate
nrounds=1000
nerr=0
for cvround in range(0, nrounds):
    teg=np.random.randint(0, cleandata.shape[0])
    wdist=np.sum((cleandata[teg, 1:10]-cleandata[:, 1:10])**2, axis=1)
    wdist[teg]=np.max(wdist)
    ptr=np.argmin(wdist)
    nerr=nerr+(1-((cleandata[teg, 10]-cleandata[ptr, 10])==0))

erate=nerr/nrounds    
    
