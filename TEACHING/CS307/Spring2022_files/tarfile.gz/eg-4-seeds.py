import math
import csv
import numpy as np

npdata=np.genfromtxt('clseeds.txt', delimiter=',')

# O dear

npdata=np.genfromtxt('cl2seeds.txt', delimiter=',')
# we get nans in the first row and in first col
# simplify life - clean again
goodflag=np.sum(np.isnan(npdata), axis=1)
cleandata=npdata[goodflag==0, :]
alldata=cleandata[:, 0:cleandata.shape[1]-1]
alllabels=cleandata[:, cleandata.shape[1]-1]

nrounds=1000
nerr=0
for cvround in range(0, nrounds):
    teg=np.random.randint(0, alldata.shape[0])
    wdist=np.sum((alldata[teg]-alldata)**2, axis=1)
    wdist[teg]=np.max(wdist)
    ptr=np.argmin(wdist)
    nerr=nerr+(1-((alllabels[teg]-alllabels[ptr])==0))

erate=nerr/nrounds    
