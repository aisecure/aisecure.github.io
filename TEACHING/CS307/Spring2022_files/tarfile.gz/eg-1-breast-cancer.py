import numpy as np

npdata=np.genfromtxt('breast-cancer-wisconsin-data.csv', delimiter=',')
#
# we'll have to clean this up - there are ?'s in the data
goodflag=np.sum(np.isnan(npdata), axis=1)

print(npdata[0, :])
cleandata=npdata[goodflag==0, :]
alldata=cleandata[:, 1:10]
alllabels=cleandata[:, 10]
test=cleandata[0:100, 1:10]
telabels=cleandata[0:100, 10]
train=cleandata[101:699, 1:10]
trlabels=cleandata[101:699, 10]

prlabels=np.zeros_like(telabels)
for i in range(0, 100):
    wdist=np.sum((test[i, :]-train)**2, axis=1)
    ptr=np.argmin(wdist)
    prlabels[i]=trlabels[ptr]

sum(prlabels==telabels)   
