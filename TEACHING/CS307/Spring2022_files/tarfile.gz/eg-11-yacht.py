import math
import csv
import numpy as np

#regdata=np.genfromtxt('yacht_hydrodynamics.data', delimiter=' ')
# o dear o dear
regdata=np.genfromtxt('cleanyacht.data', delimiter=' ')
vals=regdata[:, 6]
feats=regdata[:, 0:6]
#
# default prediction
#
pdef=np.mean(vals)
defsqerr=np.mean((vals-np.mean(vals))**2)
# can we get a better prediction with nearest neighbors?
nrounds=1000
sqerr=0
for cvround in range(0, nrounds):
    teg=np.random.randint(0, regdata.shape[0])
    wdist=np.sum((feats[teg, :]-feats)**2, axis=1)
    wdist[teg]=np.max(wdist)
    ptr=np.argmin(wdist)
    sqerr=sqerr+(vals[ptr]-vals[teg])**2
    
nnsqerr=sqerr/nrounds
# this is a lot better
# what about whitening features?

nrounds=1000
wsqerr=0
wfeats=feats/np.std(feats, axis=0)

for cvround in range(0, nrounds):
    teg=np.random.randint(0, regdata.shape[0])
    wdist=np.sum((wfeats[teg, :]-wfeats)**2, axis=1)
    wdist[teg]=np.max(wdist)
    ptr=np.argmin(wdist)
    wsqerr=wsqerr+(vals[ptr]-vals[teg])**2
    
nnwsqerr=wsqerr/nrounds
#
#
# would we actually use this?
wmse=nnwsqerr**(1/2)
np.mean(vals)
np.std(vals)

# note mild improvement
#
#
import matplotlib.pyplot as plt

pvals=np.zeros_like(vals)
wfeats=feats/np.std(feats, axis=0)

for teg in range(0, vals.shape[0]):
    wdist=np.sum((wfeats[teg, :]-wfeats)**2, axis=1)
    wdist[teg]=np.max(wdist)
    ptr=np.argmin(wdist)
    pvals[teg]=vals[ptr]

plt.scatter(vals, pvals)
plt.show()



