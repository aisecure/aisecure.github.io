import math
import csv
import numpy as np

npdata=np.genfromtxt('cl2seeds.txt', delimiter=',')
# we get nans in the first row and in first col
# simplify life - clean again
goodflag=np.sum(np.isnan(npdata), axis=1)
cleandata=npdata[goodflag==0, :]
alldata=cleandata[:, 0:cleandata.shape[1]-1]
alllabels=cleandata[:, cleandata.shape[1]-1]

# 3-NN
nrounds=1000
nerr=0
numnn=3
nalldata=alldata-np.mean(alldata, axis=0)
nalldata=alldata/np.std(alldata, axis=0)
for cvround in range(0, nrounds):
    teg=np.random.randint(0, alldata.shape[0])
    wdist=np.sum((nalldata[teg]-nalldata)**2, axis=1)
    wdist[teg]=np.max(wdist)
    indices=np.argsort(wdist)
    # now vote - this is a two class problem, so easy
    # classes are 1, 0
    wv=np.mean(alllabels[indices[0:numnn]])
    plabel=0
    if wv>0.5:
        plabel=1
    nerr=nerr+(1-(plabel-alllabels[teg])==0)

erate=nerr/nrounds    
