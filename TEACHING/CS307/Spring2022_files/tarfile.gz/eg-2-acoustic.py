import math
import csv
import numpy as np

npdata=np.genfromtxt('AcousticFeatures.csv', delimiter=',')
# we'll have to clean this up - there are ?'s in the data
# well, this doesn't work, what now?
npdata=np.genfromtxt('cleanAF.csv', delimiter=',')
# we get nans in the first row and in first col
# simplify life - clean again
npdata=np.genfromtxt('cleanerAF.csv', delimiter=',')

goodflag=np.sum(np.isnan(npdata), axis=1)
cleandata=npdata[goodflag==0, :]
alldata=cleandata[:, 1:cleandata.shape[1]]
alllabels=cleandata[:, 0]
test=cleandata[0:100, 1:cleandata.shape[1]]
telabels=cleandata[0:100, 0]
train=cleandata[101:cleandata.shape[0], 1:cleandata.shape[1]]
trlabels=cleandata[101:cleandata.shape[0], 0]

prlabels=np.zeros_like(telabels)
for i in range(0, 100):
    wdist=np.sum((test[i, :]-train)**2, axis=1)
    ptr=np.argmin(wdist)
    prlabels[i]=trlabels[ptr]

sum(prlabels==telabels)    
