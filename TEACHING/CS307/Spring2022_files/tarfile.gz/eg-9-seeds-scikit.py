import math
import csv
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
npdata=np.genfromtxt('cl2seeds.txt', delimiter=',')
neigh=KNeighborsClassifier(n_neighbors=1)
nrounds=10
avec=np.zeros(nrounds)
for round in range(0, nrounds):
    split=np.random.rand(npdata.shape[0])>0.2
    ftrain=npdata[split, 0:npdata.shape[1]-1]
    ltrain=npdata[split, npdata.shape[1]-1]
    ftest=npdata[split==0, 0:npdata.shape[1]-1]
    ltest=npdata[split==0, npdata.shape[1]-1]
    neigh.fit(ftrain, ltrain)
    plabels=neigh.predict(ftest)
    acc=np.sum(plabels==ltest)/np.sum(split==0)
    avec[round]=acc

neigh=KNeighborsClassifier(n_neighbors=1)
nrounds=10
wavec=np.zeros(nrounds)
for round in range(0, nrounds):
    split=np.random.rand(npdata.shape[0])>0.2
    ftrain=npdata[split, 0:npdata.shape[1]-1]
    scales=np.std(ftrain, axis=0)
    ftrain=ftrain/scales
    ltrain=npdata[split, npdata.shape[1]-1]
    ftest=npdata[split==0, 0:npdata.shape[1]-1]
    ftest=ftest/scales
    ltest=npdata[split==0, npdata.shape[1]-1]
    neigh.fit(ftrain, ltrain)
    plabels=neigh.predict(ftest)
    acc=np.sum(plabels==ltest)/np.sum(split==0)
    wavec[round]=acc
    
# is there an improvement?

neigh=KNeighborsClassifier(n_neighbors=3)
nrounds=10
wtavec=np.zeros(nrounds)
for round in range(0, nrounds):
    split=np.random.rand(npdata.shape[0])>0.2
    ftrain=npdata[split, 0:npdata.shape[1]-1]
    scales=np.std(ftrain, axis=0)
    ftrain=ftrain/scales
    ltrain=npdata[split, npdata.shape[1]-1]
    ftest=npdata[split==0, 0:npdata.shape[1]-1]
    ftest=ftest/scales
    ltest=npdata[split==0, npdata.shape[1]-1]
    neigh.fit(ftrain, ltrain)
    plabels=neigh.predict(ftest)
    acc=np.sum(plabels==ltest)/np.sum(split==0)
    wtavec[round]=acc


neigh=KNeighborsClassifier(n_neighbors=1)
nrounds=10
tavec=np.zeros(nrounds)
for round in range(0, nrounds):
    split=np.random.rand(npdata.shape[0])>0.2
    ftrain=npdata[split, 0:npdata.shape[1]-1]
    ltrain=npdata[split, npdata.shape[1]-1]
    ftest=npdata[split==0, 0:npdata.shape[1]-1]
    ltest=npdata[split==0, npdata.shape[1]-1]
    neigh.fit(ftrain, ltrain)
    plabels=neigh.predict(ftest)
    acc=np.sum(plabels==ltest)/np.sum(split==0)
    tavec[round]=acc
    



    

    
